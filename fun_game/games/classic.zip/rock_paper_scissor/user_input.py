def get_user_choice():
    return input("Choose rock, paper, or scissors: ").lower()

